import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const workspace = sqliteTable("workspace", {
  id: integer().primaryKey(),
  revision: integer().notNull(),
  payload: text().notNull(),
});
