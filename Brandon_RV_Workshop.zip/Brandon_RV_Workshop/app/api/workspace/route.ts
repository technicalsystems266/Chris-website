import { env } from "cloudflare:workers";

export async function GET() {
  if (!env.DB) return new Response(null,{status:503});
  const row = await env.DB.prepare("SELECT revision, payload FROM workspace WHERE id = 1").first<{revision:number,payload:string}>();
  return Response.json({revision:row?.revision ?? 0, data:row ? JSON.parse(row.payload) : null}, {headers:{"Cache-Control":"no-store"}});
}

export async function PUT(request: Request) {
  if (!env.DB) return new Response(null,{status:503});
  if (request.headers.get("origin") !== new URL(request.url).origin) return new Response(null,{status:403});
  const {revision,data} = await request.json() as {revision:number;data:unknown};
  const payload = JSON.stringify(data);
  if (!Number.isSafeInteger(revision) || revision < 0 || !payload || payload.length > 1800000) return new Response(null,{status:400});
  const result = revision === 0
    ? await env.DB.prepare("INSERT OR IGNORE INTO workspace VALUES (1, 1, ?)").bind(payload).run()
    : await env.DB.prepare("UPDATE workspace SET revision = revision + 1, payload = ? WHERE id = 1 AND revision = ?").bind(payload,revision).run();
  return result.meta.changes ? Response.json({revision:revision+1}) : new Response(null,{status:409});
}
