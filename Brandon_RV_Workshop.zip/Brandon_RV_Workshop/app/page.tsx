"use client";

import {useEffect,useState,type FormEvent,type ReactNode} from "react";
import {LayoutDashboard,ClipboardList,Users,Truck,Receipt,Settings as Gear,Plus,ArrowUpRight,Download,CalendarDays,Menu} from "lucide-react";
import {categories,emptyAmounts,initial,today,money,round,sum,totals,addDays,monday,ref,type Data,type RecordRV,type Category,type Customer,type Vehicle,type Settings,type Expense,type SupplierOrder} from "./model";

const tabs = [{name:"Overview",icon:LayoutDashboard},{name:"Work orders",icon:ClipboardList},{name:"Customers & vehicles",icon:Users},{name:"Ordering",icon:Truck},{name:"Expenses",icon:Receipt},{name:"Settings",icon:Gear}];
const fields = (form:FormEvent<HTMLFormElement>) => Object.fromEntries(new FormData(form.currentTarget)) as Record<string,string>;
const id = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), byte=>byte.toString(16).padStart(2,"0")).join("");
const dateLabel = (value:string) => value ? new Date(value.slice(0,10)+"T12:00:00Z").toLocaleDateString("en-AU",{day:"numeric",month:"short",year:"numeric",timeZone:"UTC"}) : "—";
const vehicleKinds = ["Caravan","Motorhome","Camper","Horse float"];
const jobStages = ["Unscheduled","Scheduled","In progress","Completed"];
const deliveryStages=["Not ordered","Ordered","Part received","Arrived","Cancelled"];
const supplierPayments=["Unpaid","Part paid","Paid"];
function orderStatus(order:SupplierOrder){
  return order.status==="Ordered"&&!order.reference.trim()?"Not ordered":order.status;
}
function partsStatus(r:RecordRV){
  const active=(r.orders??[]).filter(o=>o.status!=="Cancelled");
  if(!active.length)return r.orders?.length||r.parts==="Ordered"?"Not ordered":r.parts;
  if(active.every(o=>o.status==="Arrived"))return "Arrived";
  if(active.some(o=>["Arrived","Part received"].includes(o.status)))return "Part received";
  return active.some(o=>orderStatus(o)==="Ordered")?"Ordered":"Not ordered";
}
function paidPartsAwaitingOrder(record:RecordRV){
  const pending=record.orders?.filter(order=>orderStatus(order)==="Not ordered")??[];
  if(pending.some(order=>order.payment==="Paid"))return true;
  if(record.job==="Completed")return false;
  if(!pending.length&&partsStatus(record)!=="Not ordered")return false;
  const partsTotal=round(sum(record.lines.filter(line=>line.category==="Parts").map(line=>round(line.qty*line.rate)))*(1+record.settings.gst/100));
  return partsTotal>0&&totals(record).paid>=partsTotal;
}
const quoteStages = ["Enquiry","Draft","Sent","Accepted","Declined","Expired"];

function Field({label,name,value="",type="text",required=false,options,max}: {label:string;name:string;value?:string|number;type?:string;required?:boolean;options?:string[];max?:number}) {
  return <label className="field">{label}{options ? <select name={name} defaultValue={value} required={required}>{options.map(o=><option key={o}>{o}</option>)}</select> : <input name={name} type={type} defaultValue={value} required={required} maxLength={max} min={type==="number"?0:undefined} step={type==="number"?"0.01":undefined}/>}</label>;
}
function download(name:string,body:string,type:string) {
  const url=URL.createObjectURL(new Blob([body],{type}));
  const a=document.createElement("a"); a.href=url; a.download=name; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function csv(rows:(string|number)[][]) {
  return rows.map(row=>row.map(value=>'"'+String(typeof value==="string" && /^[=+\-@\t\r]/.test(value)?"'"+value:value).replaceAll('"','""')+'"').join(",")).join("\r\n");
}
function Brand(){return <div className="brand"><img className="brand-mark" src="/brv-mark.webp" alt=""/><div>BRANDON <b>RV</b><small>MOBILE REPAIR WORKSHOP</small></div></div>}
function Panel({title,action,children}:{title:string;action?:ReactNode;children:ReactNode}){return <section className="panel"><header><h2>{title}</h2>{action}</header>{children}</section>}
function Empty({children}:{children:ReactNode}){return <div className="empty">{children}</div>}
function Badge({children}:{children:string}){return <span className={"badge "+(["Completed","Accepted","Paid","Ordered","Arrived","Received"].includes(children)?"green":["Overdue","Declined","Not ordered"].includes(children)?"red":"")}>{children}</span>}

export default function App(){
  const [data,setData]=useState<Data>(initial),[revision,setRevision]=useState(0),[ready,setReady]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState(""),[notice,setNotice]=useState("");
  const [tab,setTab]=useState("Overview"),[editor,setEditor]=useState<{kind:string;id?:string;customer?:string}|null>(null),[doc,setDoc]=useState<{record:RecordRV;invoice:boolean}|null>(null);
  const [week,setWeek]=useState(""),[search,setSearch]=useState(""),[filter,setFilter]=useState("All"),[menu,setMenu]=useState(false);
  const [history,setHistory]=useState<{kind:"customer"|"vehicle";id:string}|null>(null),[orderFilter,setOrderFilter]=useState("All"),[supplierFilter,setSupplierFilter]=useState("All");
  async function load(){
    setError("");
    try{const response=await fetch("/api/workspace");if(!response.ok) throw Error();const result=await response.json() as {data:Data|null;revision:number};setData(result.data??initial);setRevision(result.revision);setReady(true);}
    catch{setError("Couldn’t load the workspace. Retry to connect.");}
  }
  useEffect(()=>{setWeek(monday(today()));void load();},[]);
  async function save(next:Data, close=true){
    if(busy||!ready)return false;
    setBusy(true);setError("");setNotice("");
    try{
      const response=await fetch("/api/workspace",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({revision,data:next})});
      if(response.status===409)throw Error("The workspace changed in another tab or device. Close this form and reload before saving.");
      if(!response.ok)throw Error("Couldn’t save. Your entries are still in the form. Try again.");
      const result=await response.json() as {revision:number};setRevision(result.revision);setData(next);if(close)setEditor(null);setNotice("Saved");return true;
    }catch(e){setError(e instanceof Error?e.message:"Couldn’t save.");return false;}
    finally{setBusy(false);}
  }
  const customer=(key:string)=>data.customers.find(c=>c.id===key);
  const vehicle=(key:string)=>data.vehicles.find(v=>v.id===key);
  const editing=data.records.find(r=>r.id===editor?.id);
  const updateRecord=(r:RecordRV,close=true)=>save({...data,records:editing||data.records.some(x=>x.id===r.id)?data.records.map(x=>x.id===r.id?r:x):[r,...data.records]},close);
  const newRecord=():RecordRV=>({id:"",number:Math.max(0,...data.records.map(r=>r.number))+1,date:today(),customer:"",vehicle:"",scope:"",type:"",quote:"Enquiry",lines:[],settings:{...data.settings},job:"",schedule:"",parts:"Not ordered",completed:"",notes:"",hours:0,actual:emptyAmounts(),invoice:"",due:"",payments:[]});
  const end=week?addDays(week,6):"";
  const inWeek=(date:string)=>!!date && date.slice(0,10)>=week && date.slice(0,10)<=end;
  const completed=data.records.filter(r=>r.job==="Completed" && inWeek(r.completed));
  const expenseRows=data.expenses.filter(e=>inWeek(e.date));
  const outstanding=data.records.filter(r=>r.invoice&&totals(r).balance>0);
  const labour=sum(completed.flatMap(r=>r.lines.filter(l=>l.category==="Labour").map(l=>round(l.qty*l.rate))));
  const actual=(category:Category)=>sum(completed.map(r=>r.actual[category]));
  const gross=sum(completed.map(r=>totals(r).profit));
  const expenses=sum(expenseRows.map(e=>e.amount));
  const upcoming=data.records.filter(r=>r.job&&r.job!=="Completed"&&r.schedule).sort((a,b)=>a.schedule.localeCompare(b.schedule));
  const filtered=data.records.filter(r=>{
    const stages=[r.job,r.quote,r.invoice?paymentStatus(r):""];
    return (filter==="All"||stages.includes(filter)) && [ref(r),customer(r.customer)?.name,vehicle(r.vehicle)?.rego,r.type,r.scope].join(" ").toLowerCase().includes(search.toLowerCase());
  });
  const registerQuery=search.trim().toLowerCase();
  const matchesRegister=(...values:string[])=>values.some(value=>value.toLowerCase().includes(registerQuery));
  const register=data.customers.map(c=>{
    const owned=data.vehicles.filter(v=>v.customer===c.id);
    const vehicles=matchesRegister(c.name,c.phone,c.email,c.address)
      ? owned
      : owned.filter(v=>matchesRegister(v.kind,v.model,v.rego,v.vin));
    return {c,vehicles,visible:matchesRegister(c.name,c.phone,c.email,c.address)||vehicles.length>0};
  }).filter(group=>group.visible);
  function go(name:string){setTab(name);setMenu(false);setSearch("");setFilter("All");}
  function paymentStatus(r:RecordRV){const t=totals(r);return t.balance===0?"Paid":r.due<today()?"Overdue":t.paid?"Part paid":"Unpaid";}
  function exportFinance(){
    const rows:(string|number)[][]=[["Record","Date","Customer or description","Labour billed","Revenue ex tax","Actual labour cost","Parts cost","Freight cost","Job consumables","Business expense","Job profit","Balance inc tax"]];
    for(const r of completed){const t=totals(r);rows.push([ref(r,"J"),r.completed,customer(r.customer)?.name??"",sum(r.lines.filter(l=>l.category==="Labour").map(l=>round(l.qty*l.rate))),t.revenue,r.actual.Labour,r.actual.Parts,r.actual.Freight,r.actual.Consumables,0,t.profit,r.invoice?t.balance:0]);}
    for(const e of expenseRows)rows.push([e.category,e.date,e.description,0,0,0,0,0,0,e.amount,0,0]);
    for(const r of outstanding.filter(r=>!completed.includes(r)))rows.push([ref(r,"INV"),r.invoice,customer(r.customer)?.name??"",0,0,0,0,0,0,0,0,totals(r).balance]);
    download("Brandon-RV-finance-"+week+".csv",csv(rows),"text/csv");
  }
  const awaitingOrder=data.records.filter(record=>record.job&&paidPartsAwaitingOrder(record));
  function orderTable(rows:RecordRV[]){return rows.length?<div className="table-wrap"><table><thead><tr><th>Reference / work</th><th>Customer / vehicle</th><th>Quote</th><th>Job</th><th>Payment</th><th className="num">Total</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td><button className="text-button" onClick={()=>setEditor({kind:"work",id:r.id})}>{ref(r)}</button><small>{r.type}</small></td><td>{customer(r.customer)?.name}<small>{vehicle(r.vehicle)?.model} {vehicle(r.vehicle)?.rego}</small></td><td><Badge>{r.quote}</Badge></td><td>{r.job?<Badge>{r.job}</Badge>:"—"}</td><td>{r.invoice?<Badge>{paymentStatus(r)}</Badge>:"—"}</td><td className="num">{money(totals(r).total)}</td></tr>)}</tbody></table></div>:<Empty>No work orders to show.</Empty>}
  return <>
    <div className="shell">
      <aside className={menu?"sidebar open":"sidebar"}><Brand/><p className="nav-label">WORKSPACE</p>{tabs.map(({name,icon:Icon})=><button key={name} className={tab===name?"nav active":"nav"} onClick={()=>go(name)}><Icon size={18}/>{name}</button>)}<div className="sidebar-footer"><span className="avatar">CB</span><div>Chris Brandon<small>Tamworth, NSW</small></div></div></aside>
      <div className="workspace">
        <header className="top"><button className="mobile icon" aria-label="Toggle navigation" onClick={()=>setMenu(!menu)}><Menu size={20}/></button><span>Workshop <b>/</b> {tab}</span><span className="private"><i/> Private workspace</span></header>
        <main>
          <div className="heading"><div><span className="eyebrow">BRANDON RV OPERATIONS</span><h1>{tab==="Overview"?"Workshop overview":tab}</h1><p>{({Overview:"Track your mobile repairs and see how the week is shaping up.", "Work orders":"Follow every enquiry, quote, job and invoice in one place.","Customers & vehicles":"Manage customer details, vehicles and their work history.",Ordering:"Track supplier orders, deliveries and supplier payments by job.",Expenses:"Log business overheads and workshop consumables.",Settings:"Manage quote defaults, business details and exports."})[tab]}</p></div>
          {ready&&tab!=="Settings"&&tab!=="Ordering"&&<button className="primary" onClick={()=>setEditor({kind:tab==="Customers & vehicles"?"customer":tab==="Expenses"?"expense":"work"})}><Plus size={17}/>{tab==="Customers & vehicles"?"New customer":tab==="Expenses"?"Add expense":"New enquiry"}</button>}</div>
          {error&&!editor&&<div role="alert" className="alert">{error} <button onClick={load}>Reload</button></div>}
          {!editor&&["Overview","Work orders","Ordering"].includes(tab)&&awaitingOrder.length>0&&<div role="alert" className="alert">
            <strong>Paid parts waiting to be ordered</strong>
            <div className="toolbar">{awaitingOrder.map(record=><button key={record.id} onClick={()=>{go("Ordering");setEditor({kind:"ordering",id:record.id});}}>{ref(record,"J")} · {customer(record.customer)?.name||record.type||"View order"}</button>)}</div>
          </div>}
          {notice&&!editor&&<div className="saved" role="status">{notice}</div>}
          {!ready?<Empty>{error?"Workspace unavailable":"Loading workspace…"}</Empty>:<>
          {tab==="Overview"&&<><div className="period"><div><CalendarDays size={18}/><strong>Weekly snapshot</strong><span>{dateLabel(week)} – {dateLabel(end)}</span></div><div><label>Week of <input type="date" value={week} onChange={e=>e.target.value&&setWeek(monday(e.target.value))}/></label><button onClick={exportFinance}><Download size={16}/> CSV</button></div></div>
          <div className="metrics">{[
            ["Labour earnings",money(labour),"Labour billed on jobs completed this week"],
            ["Direct job costs",money(sum(categories.map(actual))),"Parts "+money(actual("Parts"))+" · Freight "+money(actual("Freight"))],
            ["Business expenses",money(expenses),"Consumables "+money(sum(expenseRows.filter(e=>e.category==="Consumables").map(e=>e.amount)))],
            ["Operating profit",money(round(gross-expenses)),"Completed job revenue less costs and overheads"],
            ["Outstanding payments",money(sum(outstanding.map(r=>totals(r).balance))),outstanding.length+" open invoices across all dates"]
          ].map(([label,value,detail])=><section className="metric" key={label}><span>{label}</span><strong>{value}</strong><small>{detail}</small></section>)}</div>
          <div className="split"><Panel title="Upcoming work">{upcoming.length?upcoming.slice(0,5).map(r=><div className="list-line" key={r.id}><button className="text-button" onClick={()=>setEditor({kind:"work",id:r.id})}>{r.type||ref(r,"J")}<small>{customer(r.customer)?.name} · <Badge>{partsStatus(r)}</Badge></small></button><span>{dateLabel(r.schedule)} {r.schedule.slice(11)}</span></div>):<Empty>No visits scheduled. Add a date to an accepted job to see it here.</Empty>}</Panel>
          <Panel title="Weekly cost breakdown">{categories.map(c=><div className="list-line" key={c}><span>{c==="Labour"?"Labour cost":c==="Consumables"?"Job consumables":c}</span><strong>{money(actual(c))}</strong></div>)}<div className="list-line"><span>Job profit before overheads</span><strong>{money(gross)}</strong></div></Panel></div>
          <Panel title="Recent work" action={<button onClick={()=>go("Work orders")}>All work orders <ArrowUpRight size={15}/></button>}>{orderTable(data.records.slice(0,6))}</Panel></>}
          {tab==="Work orders"&&<Panel title="Work register" action={<div className="toolbar"><input aria-label="Search work orders" placeholder="Search jobs, names or rego" value={search} onChange={e=>setSearch(e.target.value)}/><select aria-label="Filter work orders" value={filter} onChange={e=>setFilter(e.target.value)}>{["All",...quoteStages,...jobStages,"Unpaid","Part paid","Paid","Overdue"].map(s=><option key={s}>{s}</option>)}</select></div>}>{orderTable(filtered)}</Panel>}
          {tab==="Customers & vehicles"&&<Panel title="Customer and vehicle register" action={<input type="search" aria-label="Search customers and vehicles" placeholder="Search name, model, rego or VIN" value={search} onChange={e=>setSearch(e.target.value)}/>}>{register.length?register.map(({c,vehicles})=><div className="register-group" key={c.id}><div className="list-line"><div><strong>{c.name}</strong><small>{[c.phone,c.email,c.address].filter(Boolean).join(" · ")}</small></div><div className="toolbar"><button onClick={()=>setEditor({kind:"customer",id:c.id})}>Edit customer</button><button onClick={()=>setHistory({kind:"customer",id:c.id})}>Customer history</button><button onClick={()=>setEditor({kind:"vehicle",customer:c.id})}><Plus size={15}/> Add vehicle</button></div></div>{vehicles.map(v=><div className="list-line vehicle-row" key={v.id}><div><strong>{v.model}</strong><small>{v.kind} · {v.rego||"No rego"}</small></div><div className="toolbar"><button onClick={()=>setEditor({kind:"vehicle",id:v.id})}>Edit vehicle</button><button onClick={()=>setHistory({kind:"vehicle",id:v.id})}>Vehicle history</button></div></div>)}</div>):<Empty>{registerQuery?"No customers or vehicles match your search.":"Add a customer, then add their vehicles from this register."}</Empty>}</Panel>}
          {tab==="Ordering"&&<Panel title="Supplier order register" action={<div className="toolbar"><select aria-label="Delivery filter" value={orderFilter} onChange={e=>setOrderFilter(e.target.value)}>{["All",...deliveryStages,"Not required"].map(s=><option key={s}>{s}</option>)}</select><select aria-label="Supplier payment filter" value={supplierFilter} onChange={e=>setSupplierFilter(e.target.value)}>{["All",...supplierPayments,"No supplier order"].map(s=><option key={s}>{s}</option>)}</select></div>}>
          {(()=>{const rows=data.records.filter(r=>r.job).flatMap(r=>(r.orders?.length?r.orders:[null]).map(order=>({r,order,status:order?orderStatus(order):(r.parts==="Received"?"Arrived":partsStatus(r)),payment:order?.payment??"No supplier order"}))).filter(x=>(orderFilter==="All"||x.status===orderFilter)&&(supplierFilter==="All"||x.payment===supplierFilter));return rows.length?<div className="table-wrap"><table><thead><tr><th>Job</th><th>Customer / vehicle</th><th>Supplier / order</th><th>Delivery</th><th>Supplier payment</th></tr></thead><tbody>{rows.map(({r,order,status,payment})=><tr key={r.id+(order?.id??"")}><td><button className="text-button" onClick={()=>setEditor({kind:"ordering",id:r.id})}>{ref(r,"J")}</button><small>{r.type}</small></td><td>{customer(r.customer)?.name}<small>{vehicle(r.vehicle)?.model}</small></td><td>{order?.supplier||"—"}<small>{[order?.reference,order?.items].filter(Boolean).join(" · ")}</small></td><td><Badge>{status}</Badge></td><td><Badge>{payment}</Badge></td></tr>)}</tbody></table></div>:<Empty>No matching orders. Accepted quotes appear here after conversion to jobs.</Empty>})()}</Panel>}
          {tab==="Expenses"&&<Panel title="Expense register" action={<button onClick={()=>download("Brandon-RV-expenses.csv",csv([["Date","Category","Description","Amount"],...data.expenses.map(e=>[e.date,e.category,e.description,e.amount])]),"text/csv")}>Export CSV</button>}>{data.expenses.length?data.expenses.map((e,i)=><div className="list-line" key={i}><button className="text-button" onClick={()=>setEditor({kind:"expense",id:String(i)})}>{e.description}<small>{dateLabel(e.date)} · {e.category}</small></button><strong>{money(e.amount)}</strong></div>):<Empty>No overheads logged. Record costs here that are separate from individual jobs.</Empty>}</Panel>}
          {tab==="Settings"&&<Panel title="Business and pricing defaults"><SettingsForm key={revision} value={data.settings} busy={busy} onSave={settings=>save({...data,settings})}/><div className="section-pad toolbar"><button onClick={()=>download("Brandon-RV-backup-"+today()+".json",JSON.stringify(data,null,2),"application/json")}><Download size={16}/> Export workspace JSON</button><button onClick={exportFinance}>Export weekly finance CSV</button></div></Panel>}
          </>}
        </main>
      </div>
    </div>
    {history&&!editor&&<div className="overlay"><section className="dialog" role="dialog" aria-modal="true" aria-label="Job history"><header><h2>{history.kind==="customer"?customer(history.id)?.name:vehicle(history.id)?.model} · Job history</h2><button aria-label="Close history" onClick={()=>setHistory(null)}>✕</button></header>{orderTable(data.records.filter(r=>r.job&&(history.kind==="customer"?r.customer:r.vehicle)===history.id))}</section></div>}
    {editor&&<div className="overlay"><section className="dialog" role="dialog" aria-modal="true" aria-label="Edit workspace record"><header><h2>{editor.kind==="work"?editing?ref(editing)+" · "+(editing.type||"Work order"):"New enquiry":(editor.id?"Edit ":"New ")+editor.kind}</h2><button aria-label="Close" onClick={()=>{setEditor(null);setError("");}} disabled={busy}>✕</button></header>{error&&<div className="alert" role="alert">{error}</div>}
    {editor.kind==="work"&&<WorkForm key={editing?.id||"new"} record={editing??newRecord()} data={data} busy={busy} onSave={updateRecord} onDoc={(record,invoice)=>setDoc({record,invoice})} fail={setError}/>}
    {editor.kind==="ordering"&&editing&&<OrderingForm record={editing} busy={busy} onSave={updateRecord}/>}
    {editor.kind==="customer"&&<form className="section-pad form-grid" onSubmit={e=>{e.preventDefault();const c={...fields(e),id:editor.id||id()} as Customer;void save({...data,customers:editor.id?data.customers.map(x=>x.id===c.id?c:x):[...data.customers,c]});}}>{["name","phone","email","address"].map(n=><Field key={n} label={n[0].toUpperCase()+n.slice(1)} name={n} value={customer(editor.id||"")?.[n as keyof Customer]} type={n==="email"?"email":n==="phone"?"tel":"text"} required={n==="name"} max={n==="address"?140:90}/>)}<button className="primary" disabled={busy}>Save customer</button></form>}
    {editor.kind==="vehicle"&&<form className="section-pad form-grid" onSubmit={e=>{e.preventDefault();const v={...fields(e),id:editor.id||id()} as Vehicle;void save({...data,vehicles:editor.id?data.vehicles.map(x=>x.id===v.id?{...v,customer:x.customer}:x):[...data.vehicles,v]});}}>
    <label className="field">Customer<select name="customer" required disabled={!!editor.id} defaultValue={vehicle(editor.id||"")?.customer||editor.customer||""}><option value="">Select customer</option>{data.customers.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
    {data.customers.length===0&&<p>Add a customer first.</p>}
    <Field label="Vehicle type" name="kind" options={vehicleKinds} value={vehicle(editor.id||"")?.kind||"Caravan"}/>
    {([["model","Make / model / year"],["rego","Registration"],["vin","VIN / chassis number"]] as const).map(([n,label])=><Field key={n} name={n} label={label} value={vehicle(editor.id||"")?.[n]} required={n==="model"} max={75}/>)}<button className="primary" disabled={busy||!data.customers.length}>Save vehicle</button></form>}
    {editor.kind==="expense"&&<ExpenseForm value={editor.id===undefined?undefined:data.expenses[Number(editor.id)]} busy={busy} onSave={expense=>save({...data,expenses:editor.id===undefined?[expense,...data.expenses]:data.expenses.map((x,i)=>i===Number(editor.id)?expense:x)})}/>}
    </section></div>}
    {doc&&<Document record={doc.record} invoice={doc.invoice} customer={customer(doc.record.customer)} vehicle={vehicle(doc.record.vehicle)} close={()=>setDoc(null)}/>}
  </>;
}

function SettingsForm({value,busy,onSave}:{value:Settings;busy:boolean;onSave:(v:Settings)=>void}){
  return <form className="section-pad form-grid" onSubmit={e=>{e.preventDefault();const f=fields(e);onSave({...f,gst:+f.gst,labour:+f.labour,labourCost:+f.labourCost,validity:+f.validity} as Settings);}}>
    <Field label="Phone" name="phone" type="tel" value={value.phone} max={30}/><Field label="Email" name="email" type="email" value={value.email} max={80}/><Field label="ABN" name="abn" value={value.abn} max={20}/>
    <Field label="GST rate (%) · 0 for no GST" name="gst" type="number" required value={value.gst}/><Field label="Default hourly charge (ex GST)" name="labour" type="number" required value={value.labour}/><Field label="Default hourly labour cost" name="labourCost" type="number" required value={value.labourCost}/>
    <label className="field">Quote validity (days)<input type="number" min="1" max="365" name="validity" required defaultValue={value.validity}/></label>
    <label className="field full">Quote message<textarea name="terms" defaultValue={value.terms}/></label>
    <p className="full hint">New enquiries use these defaults. Each quote keeps its own pricing and tax settings.</p><button className="primary" disabled={busy}>Save settings</button>
  </form>;
}
function ExpenseForm({value,busy,onSave}:{value?:Expense;busy:boolean;onSave:(v:Expense)=>void}){
  return <form className="section-pad form-grid" onSubmit={e=>{e.preventDefault();const f=fields(e);onSave({...f,amount:+f.amount} as Expense);}}>
    <Field label="Date" name="date" type="date" required value={value?.date||today()}/><Field label="Category" name="category" options={["Consumables","Tools","Fuel and travel","Insurance","Admin","Other"]} value={value?.category||"Other"}/><Field label="Description" name="description" required max={160} value={value?.description}/><Field label="Amount for profit reporting" name="amount" type="number" required value={value?.amount}/><p className="full hint">Record job-specific costs on the work order to avoid counting them twice.</p><button className="primary" disabled={busy}>Save expense</button>
  </form>;
}
function WorkForm({record,data,busy,onSave,onDoc,fail}:{record:RecordRV;data:Data;busy:boolean;onSave:(r:RecordRV,close?:boolean)=>Promise<boolean>;onDoc:(r:RecordRV,invoice:boolean)=>void;fail:(s:string)=>void}){
  const [r,set]=useState(record),[section,setSection]=useState("Enquiry"),[payment,setPayment]=useState({date:today(),amount:"",method:"Bank transfer"});
  const patch=(v:Partial<RecordRV>)=>set(old=>({...old,...v}));
  const t=totals(r);
  const locked=!!r.job;
  const vehicleList=data.vehicles.filter(v=>v.customer===r.customer);
  async function commit(next:RecordRV,close=false){
    if(!next.customer||!next.vehicle||!next.type.trim()){fail("Choose a customer and vehicle and enter a job type on the Enquiry tab.");setSection("Enquiry");return;}
    if(next.lines.some(l=>![l.qty,l.rate,l.cost].every(Number.isFinite))){fail("Enter valid numbers for quote quantities, prices and costs.");setSection("Quote");return;}
    if(next.insurance&&["Sent","Accepted"].includes(next.quote)&&(!next.insurance.insurer.trim()||!next.insurance.claim.trim())){fail("Enter the insurer and claim number before sending or accepting an insurance quote.");setSection("Quote");return;}
    if(next.job==="Scheduled"&&!next.schedule){fail("Enter a scheduled visit date and time.");return;}
    if(next.invoice&&next.due<next.invoice){fail("The due date must be on or after the invoice date.");return;}
    if(next.job==="Completed"&&!next.completed){fail("Enter a completion date.");return;}
    const value={...next,id:next.id||id()};
    if(await onSave(value,close)){set(value);return true;}
    return false;
  }
  function lineChange(index:number,change:Partial<RecordRV["lines"][number]>){patch({lines:r.lines.map((line,i)=>i===index?{...line,...change}:line)});}
  return <form onSubmit={e=>{e.preventDefault();void commit(r,true);}}>
    <nav className="steps" aria-label="Work order sections">{["Enquiry","Quote","Job","Invoice"].map(s=><button key={s} type="button" className={section===s?"selected":""} onClick={()=>setSection(s)}>{s}</button>)}</nav>
    <div className="section-pad">
    {section==="Enquiry"&&<div className="form-grid">
      {!data.customers.length&&<p className="full hint">Create a customer and their vehicle in the workspace registers first.</p>}
      <label className="field">Customer<select required disabled={locked} value={r.customer} onChange={e=>patch({customer:e.target.value,vehicle:""})}><option value="">Choose customer</option>{data.customers.map(c=><option value={c.id} key={c.id}>{c.name}</option>)}</select></label>
      <label className="field">Vehicle<select required disabled={locked} value={r.vehicle} onChange={e=>patch({vehicle:e.target.value})}><option value="">Choose vehicle</option>{vehicleList.map(v=><option value={v.id} key={v.id}>{v.kind} · {v.model} {v.rego}</option>)}</select></label>
      <label className="field">Job type<input maxLength={75} required value={r.type} onChange={e=>patch({type:e.target.value})}/></label>
      <label className="field full">Enquiry and scope of work<textarea maxLength={360} value={r.scope} readOnly={locked} onChange={e=>patch({scope:e.target.value})}/></label>
    </div>}
    {section==="Quote"&&<>
      <div className="form-grid quote-kind"><label className="field">Quote type<select value={r.insurance?"Insurance":"Standard"} disabled={locked} onChange={e=>patch({insurance:e.target.value==="Insurance"?{insurer:"",claim:"",policy:"",contact:""}:undefined})}><option>Standard</option><option>Insurance</option></select></label>
      {r.insurance&&([["insurer","Insurer"],["claim","Claim number"],["policy","Policy number"],["contact","Claims contact"]] as const).map(([key,label])=><label key={key} className="field">{label}<input maxLength={65} readOnly={locked} value={r.insurance?.[key]??""} onChange={e=>r.insurance&&patch({insurance:{...r.insurance,[key]:e.target.value}})}/></label>)}</div>
      <div className="form-grid"><label className="field">Quote status<select disabled={locked} value={r.quote} onChange={e=>patch({quote:e.target.value})}>{quoteStages.map(s=><option key={s}>{s}</option>)}</select></label>
      <label className="field">Quote date<input type="date" required value={r.date} readOnly={locked} onChange={e=>e.target.value&&patch({date:e.target.value})}/></label></div>
      <div className="table-wrap line-table"><table><thead><tr><th>Category</th><th>Customer description</th><th>Qty / hrs</th><th>Unit price</th><th>Unit cost</th><th/></tr></thead><tbody>{r.lines.map((l,i)=><tr key={i}><td><select aria-label="Category" value={l.category} disabled={locked} onChange={e=>{const category=e.target.value as Category;lineChange(i,{category,rate:category==="Labour"?r.settings.labour:0,cost:category==="Labour"?r.settings.labourCost:0});}}>{categories.map(c=><option key={c}>{c}</option>)}</select></td><td><input aria-label="Description" maxLength={72} value={l.description} readOnly={locked} onChange={e=>lineChange(i,{description:e.target.value})}/></td>{(["qty","rate","cost"] as const).map(k=><td key={k}><input aria-label={k} type="number" min="0" step="0.01" value={l[k]} readOnly={locked} onChange={e=>lineChange(i,{[k]:+e.target.value})}/></td>)}<td>{!locked&&<button aria-label="Remove line" type="button" onClick={()=>patch({lines:r.lines.filter((_,j)=>i!==j)})}>✕</button>}</td></tr>)}</tbody></table></div>
      <div className="toolbar">{!locked&&<button type="button" disabled={r.lines.length>=12} onClick={()=>patch({quote:r.quote==="Enquiry"?"Draft":r.quote,lines:[...r.lines,{category:"Labour",description:"",qty:1,rate:r.settings.labour,cost:r.settings.labourCost}]})}><Plus size={16}/> Add line</button>}
      {r.lines.length>0&&r.customer&&r.vehicle&&<button type="button" onClick={()=>onDoc(r,false)}>Preview quote</button>}
      {r.quote==="Accepted"&&!r.job&&<button type="button" disabled={busy} onClick={async()=>{if(await commit({...r,job:"Unscheduled"}))setSection("Job");}}>Convert to job</button>}</div>
      <p className="hint">Up to 12 lines per A4 quote. Unit costs are internal. Prices are entered before GST.</p>
      <div className="summary"><span>GST ({r.settings.gst}%) <b>{money(t.tax)}</b></span><span>Quote total <b>{money(t.total)}</b></span><span>Estimated profit <b>{money(t.estimate)}</b></span></div>
    </>}
    {section==="Job"&&(r.job?<><div className="form-grid">
      <label className="field">Job progress<select value={r.job} onChange={e=>patch({job:e.target.value,completed:e.target.value==="Completed"?r.completed||today():r.completed})}>{jobStages.map(s=><option key={s}>{s}</option>)}</select></label>
      <label className="field">Visit date and time<input type="datetime-local" value={r.schedule} onChange={e=>patch({schedule:e.target.value,job:r.job==="Unscheduled"&&e.target.value?"Scheduled":r.job})}/></label>
      <label className="field">Parts status<select value={partsStatus(r)} disabled={!!r.orders?.length} onChange={e=>patch({parts:e.target.value})}>{["Not ordered","Ordered","Part received","Received","Arrived","Not required"].map(s=><option key={s} disabled={s==="Ordered"}>{s}</option>)}</select></label>
      <label className="field">Completion date<input type="date" value={r.completed} onChange={e=>patch({completed:e.target.value})}/></label>
      <label className="field full">Progress, parts order references and work performed<textarea value={r.notes} maxLength={2500} onChange={e=>patch({notes:e.target.value})}/></label>
      <label className="field">Actual hours<input type="number" min="0" step="0.01" value={r.hours} onChange={e=>patch({hours:+e.target.value})}/></label>
      {categories.map(c=><label key={c} className="field">Actual {c.toLowerCase()} cost<input type="number" min="0" step="0.01" value={r.actual[c]} onChange={e=>patch({actual:{...r.actual,[c]:+e.target.value}})}/></label>)}
    </div><p className="hint">Enter costs on the same tax basis as revenue. Actual profit uses the agreed quote revenue before GST and the actual costs entered here.</p>
      <div className="summary"><span>Estimated profit <b>{money(t.estimate)}</b></span><span>Actual profit <b>{money(t.profit)}</b></span><span>Variance <b>{money(t.profit-t.estimate)}</b></span></div></>:<Empty>Set the quote to Accepted, then select Convert to job on the Quote tab.</Empty>)}
    {section==="Invoice"&&(r.job?<>{!r.invoice?<><p>Use the accepted quote to create {ref(r,"INV")}.</p><button type="button" disabled={busy} onClick={()=>void commit({...r,invoice:today(),due:addDays(today(),7)})}>Create invoice</button></>:<>
      <div className="form-grid"><label className="field">Invoice date<input type="date" required value={r.invoice} onChange={e=>e.target.value&&patch({invoice:e.target.value})}/></label><label className="field">Due date<input type="date" required value={r.due} onChange={e=>e.target.value&&patch({due:e.target.value})}/></label></div>
      <div className="summary"><span>Invoice total <b>{money(t.total)}</b></span><span>Paid <b>{money(t.paid)}</b></span><span>Balance <b>{money(t.balance)}</b></span></div>
      <button type="button" onClick={()=>onDoc(r,true)}>Preview invoice</button>
      <h3>Payments</h3>
      {r.payments.map((p,i)=><div className="list-line" key={i}><span>{dateLabel(p.date)} · {p.method}</span><strong>{money(p.amount)}</strong></div>)}
      {t.balance>0&&<><div className="form-grid"><label className="field">Payment date<input type="date" value={payment.date} onChange={e=>setPayment({...payment,date:e.target.value})}/></label><label className="field">Payment amount<input type="number" min="0" step="0.01" max={t.balance} value={payment.amount} onChange={e=>setPayment({...payment,amount:e.target.value})}/></label><label className="field">Method<select value={payment.method} onChange={e=>setPayment({...payment,method:e.target.value})}>{["Bank transfer","Card","Cash","Other"].map(m=><option key={m}>{m}</option>)}</select></label></div>
      <button type="button" disabled={busy} onClick={async()=>{const amount=round(+payment.amount);if(!payment.date||amount<=0||amount>t.balance){fail("Enter a payment date and an amount within the outstanding balance.");return;}if(await commit({...r,payments:[...r.payments,{...payment,amount}]}))setPayment({...payment,amount:""});}}>Record payment</button></>}
    </>}</>:<Empty>Convert the accepted quote to a job before creating an invoice.</Empty>)}
    </div><footer className="dialog-footer"><button type="submit" className="primary" disabled={busy}>{busy?"Saving…":"Save work order"}</button></footer>
  </form>;
}

function Document({record:r,invoice,customer,vehicle,close}:{record:RecordRV;invoice:boolean;customer?:Customer;vehicle?:Vehicle;close:()=>void}){
  const t=totals(r),title=invoice?(r.settings.gst&&r.settings.abn?"Tax invoice":"Invoice"):r.insurance?"Insurance quote":"Quote",number=ref(r,invoice?"INV":"Q");
  return <div className="overlay document-overlay" role="dialog" aria-modal="true" aria-label={title}>
    <div className="doc-wrap"><div className="doc-actions"><button onClick={close}>Close preview</button><button className="primary" onClick={()=>window.print()}>Print / Save PDF</button></div>
    <article className="document"><div className="doc-top"><div><img className="doc-logo" src="/brv-logo.webp" alt="Brandon RV · From Factory Experience to Repairs On The Go"/><small>{[r.settings.phone,r.settings.email,r.settings.abn&&"ABN "+r.settings.abn].filter(Boolean).join(" · ")}</small></div><div><h1>{title}</h1><strong>{number}</strong></div></div>
    <div className="doc-info"><div><b>Prepared for</b><br/>{customer?.name}<br/>{[customer?.phone,customer?.email].filter(Boolean).join(" · ")}<br/>{customer?.address}</div><div><b>Your vehicle</b><br/>{vehicle?.kind} · {vehicle?.model}<br/>{vehicle?.rego&&"Rego "+vehicle.rego}</div><div><b>{dateLabel(invoice?r.invoice:r.date)}</b><br/>{invoice?"Due":"Valid until"} {dateLabel(invoice?r.due:addDays(r.date,r.settings.validity))}</div></div>
    {r.insurance&&<p className="claim-details"><b>Insurance claim</b> · {[r.insurance.insurer,r.insurance.claim&&"Claim "+r.insurance.claim,r.insurance.policy&&"Policy "+r.insurance.policy,r.insurance.contact&&"Contact "+r.insurance.contact].filter(Boolean).join(" · ")}</p>}
    <h2>{r.type}</h2><p className="scope">{r.scope.replace(/\s+/g," ")}</p>
    <table><thead><tr><th>Work and materials</th><th>Qty</th><th className="num">Unit price</th><th className="num">Amount</th></tr></thead><tbody>{r.lines.map((l,i)=><tr key={i}><td><b>{l.category}</b> · {l.description}</td><td>{l.qty}</td><td className="num">{money(l.rate)}</td><td className="num">{money(round(l.rate*l.qty))}</td></tr>)}</tbody></table>
    <div className="doc-totals"><span>Subtotal <b>{money(t.revenue)}</b></span><span>GST ({r.settings.gst}%) <b>{money(t.tax)}</b></span><span className="doc-grand">Total <b>{money(t.total)}</b></span>{invoice&&<><span>Paid <b>{money(t.paid)}</b></span><span>Balance due <b>{money(t.balance)}</b></span></>}</div>
    <div className="doc-note"><b>{invoice?"Thanks for choosing Brandon RV":"Ready to go ahead?"}</b><p style={invoice?undefined:{whiteSpace:"pre-wrap"}}>{invoice?"Please get in touch if you need payment details or have a question about this invoice.":r.settings.terms}</p></div>
    </article></div></div>;
}

function OrderingForm({record,busy,onSave}:{record:RecordRV;busy:boolean;onSave:(r:RecordRV)=>void}){
  const [orders,setOrders]=useState((record.orders??[]).map(order=>({...order,status:orderStatus(order)})));
  function edit(index:number,change:Partial<SupplierOrder>){setOrders(orders.map((order,i)=>i===index?{...order,...change,status:orderStatus({...order,...change})}:order));}
  return <form className="section-pad" onSubmit={e=>{e.preventDefault();onSave({...record,orders});}}>
    <h3>{ref(record,"J")} · {record.type}</h3>
    <p className="hint">Track each supplier order separately. Enter the supplier order number to enable Ordered. Supplier payments are separate from customer invoice payments.</p>
    {orders.map((o,i)=><fieldset className="form-grid supplier-order" key={o.id}><legend>Order {i+1}</legend>
      {([["supplier","Supplier"],["reference","Order number"],["items","Parts / items"]] as const).map(([key,label])=><label key={key} className="field">{label}<input required={key==="supplier"} maxLength={150} value={o[key]} onChange={e=>edit(i,{[key]:e.target.value})}/></label>)}
      <label className="field">Delivery status<select value={o.status} onChange={e=>edit(i,{status:e.target.value})}>{deliveryStages.map(s=><option key={s} disabled={s==="Ordered"&&!o.reference.trim()}>{s}</option>)}</select></label>
      <label className="field">Supplier payment<select value={o.payment} onChange={e=>edit(i,{payment:e.target.value})}>{supplierPayments.map(s=><option key={s}>{s}</option>)}</select></label>
    </fieldset>)}
    <div className="toolbar"><button type="button" onClick={()=>setOrders([...orders,{id:id(),supplier:"",reference:"",items:"",status:"Not ordered",payment:"Unpaid"}])}><Plus size={16}/> Add supplier order</button><button className="primary" disabled={busy}>Save orders</button></div>
  </form>;
}
