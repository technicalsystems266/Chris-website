export const categories = ["Labour", "Parts", "Freight", "Consumables"] as const;
export type Category = typeof categories[number];
export type Amounts = Record<Category, number>;
export type Customer = {id:string; name:string; phone:string; email:string; address:string};
export type Vehicle = {id:string; customer:string; kind:string; model:string; rego:string; vin:string};
export type Line = {category:Category; description:string; qty:number; rate:number; cost:number};
export type Settings = {phone:string; email:string; abn:string; gst:number; labour:number; labourCost:number; validity:number; terms:string};
export type Payment = {date:string; amount:number; method:string};
export type SupplierOrder = {id:string; supplier:string; reference:string; items:string; status:string; payment:string};
export type Insurance = {insurer:string; claim:string; policy:string; contact:string};
export type RecordRV = {
  insurance?:Insurance; orders?:SupplierOrder[];
  id:string; number:number; date:string; customer:string; vehicle:string; scope:string; type:string;
  quote:string; lines:Line[]; settings:Settings; job:string; schedule:string; parts:string;
  completed:string; notes:string; hours:number; actual:Amounts; invoice:string; due:string; payments:Payment[];
};
export type Expense = {date:string; category:string; description:string; amount:number};
export type Data = {customers:Customer[]; vehicles:Vehicle[]; records:RecordRV[]; expenses:Expense[]; settings:Settings};
export const emptyAmounts = ():Amounts => ({Labour:0,Parts:0,Freight:0,Consumables:0});
export const initial:Data = {customers:[],vehicles:[],records:[],expenses:[],settings:{phone:"0407 189 087",email:"enquires@brandonrv.com.au",abn:"",gst:0,labour:0,labourCost:0,validity:14,terms:"Please get in touch to accept this quote or ask about the work. We’ll confirm availability and arrange a time that suits."}};
export const today = () => new Intl.DateTimeFormat("en-CA",{timeZone:"Australia/Sydney",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date());
export const money = (n:number) => new Intl.NumberFormat("en-AU",{style:"currency",currency:"AUD"}).format(n);
export const round = (n:number) => Math.round((n+Number.EPSILON)*100)/100;
export const sum = (ns:number[]) => round(ns.reduce((a,b)=>a+b,0));
export function totals(r:RecordRV) {
  const revenue = sum(r.lines.map(l=>round(l.qty*l.rate)));
  const tax = round(revenue*r.settings.gst/100);
  const cost = sum(r.lines.map(l=>round(l.qty*l.cost)));
  const paid = sum(r.payments.map(p=>p.amount));
  const actual = sum(Object.values(r.actual));
  return {revenue,tax,total:sum([revenue,tax]),cost,actual,estimate:round(revenue-cost),profit:round(revenue-actual),paid,balance:Math.max(0,round(revenue+tax-paid))};
}
export function addDays(date:string, days:number) {
  const d = new Date(date+"T00:00:00Z");
  d.setUTCDate(d.getUTCDate()+days);
  return d.toISOString().slice(0,10);
}
export const monday = (date:string) => addDays(date,-((new Date(date+"T00:00:00Z").getUTCDay()+6)%7));
export const ref = (r:RecordRV,prefix="Q") => prefix+"-"+String(r.number).padStart(4,"0");
